package service;

import bean.CustomerBean;

public class BillServiceImpl implements IBillService {

	@Override
	public String calculateBill(CustomerBean bean) {
		// TODO Auto-generated method stub
		return null;
	}

	public boolean validate(CustomerBean bean) {
		// TODO Auto-generated method stub
		return false;
	}

	public boolean verifyLogin(CustomerBean bean) {
		// TODO Auto-generated method stub
		return false;
	}

}
