package service;

import bean.CustomerBean;

public interface IBillService {

	public String calculateBill(CustomerBean bean);
}
