package com;

import accountTypes.AccountClass;

public class SavAccount extends AccountClass {
	
	//private int acc;
	public int demo=123;
	//super.demo;
	public final int x=7;
	
	public void withdraw() {
		System.out.println("this is sav account withdraw");
	}
	public void deposit() {
		System.out.println("this is savings account deposit");
	}
	public SavAccount() {
		//super();
		System.out.println("i am default of sav account");
		System.out.println(super.demo);
	}	
		public void withdraw(int x)
		{
			System.out.println("overloading with one parameter");
		}
		public void withdraw(int x, int y)
		{
			//x++;
			System.out.println("overloading with two parameters");
		}
		public void withdraw(int x,int y,int z) {
			System.out.println("overloading with three patrameters");
		}
	}

