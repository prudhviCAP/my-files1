package com;

public class SportsCar extends Car{

		public void move() {
			System.out.println("this is sub calss move");
		}
		
		public int capacity() {
			int l=2;
			System.out.println("this is sub class capacity");
			return l;
		}
		public String fuel() {
			String x="sub class fuel";
			System.out.println("this is sub class fuel");
			return x;
		}
		
		public String nothing() {
			System.out.println("this is sub nothing");
			String str = new String();
			return str;
		}
}
