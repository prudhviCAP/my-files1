package com;
public class Car {

		public void move() {
			System.out.println("this is super calss move");
			
		}
		
		public int capacity() {
			int i=100;
			System.out.println("this is super class capacity");
			return i;
		}
		
		public String fuel() {
			String f="super class fuel";
			System.out.println("this is super class fuel");
			return f;
		}
		
		public Object nothing() {
			System.out.println("this is nothing");
			Object obj=new Object();
			return obj;
		}
}
