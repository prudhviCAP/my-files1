package com;

import accountTypes.AccountClass;

public class CurrAccount extends AccountClass{
	//private int acc;
	
	public int demo=100;
	
	public void deposit() {
		System.out.println("this is current account deposit");
	}
	public void withdraw() {
		System.out.println("this is current account withdraw");
	}
	public CurrAccount() {
		super();
		System.out.println("im default constructor of curraccount");
		System.out.println(super.demo);
	}
	
}
