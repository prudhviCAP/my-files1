package com;

public class CarMain {
	public static void main(String[] args) {
		
		SportsCar miniCar = new SportsCar();
			miniCar.move();
			miniCar.capacity();
			miniCar.fuel();
			miniCar.nothing();
		
		Car bigCar = new Car();
			bigCar.move();
			bigCar.capacity();
			bigCar.fuel();
			bigCar.nothing();
	}
}
                   