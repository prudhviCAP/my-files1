package com;

public class Client {
	public static void main(String[] args) {
		SavAccount obj1 = new SavAccount();
		//CurrAccount obj2 = new CurrAccount();
		
		//obj1.withdraw();
		//System.out.println(obj1.withdraw());
		//obj2.withdraw();
		//obj1.details();
		//obj2.details();
		obj1.withdraw();
		obj1.withdraw(100);
		obj1.withdraw(100,100);
		obj1.withdraw(100,200,300);
		
	}
}
