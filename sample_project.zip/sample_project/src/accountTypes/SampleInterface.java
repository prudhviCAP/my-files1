package accountTypes;

public interface SampleInterface {
		static void name() {
			System.out.println("no");
		}
		default void age() {
			System.out.println("hi");
		}
		void contact();
		void brake();
		
		
}
