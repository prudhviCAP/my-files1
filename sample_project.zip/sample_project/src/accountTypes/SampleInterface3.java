package accountTypes;

public interface SampleInterface3 {
	void accelerate();
}
