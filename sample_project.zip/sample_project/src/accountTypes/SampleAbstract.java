package accountTypes;

public abstract class SampleAbstract {
	
		public abstract void name();
		public abstract void contact();
		public abstract void age();
		public void details() {
			System.out.println("details");
		}

}
