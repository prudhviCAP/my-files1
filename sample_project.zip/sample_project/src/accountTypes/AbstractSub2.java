package accountTypes;

public class AbstractSub2 implements SampleInterface,SampleInterface2{

	//@Override
	//public void name();
	@Override
	public void contact() {
		// TODO Auto-generated method stub
		System.out.println("101");
	}

	@Override
	public void age()
	{
//		// TODO Auto-generated method stub
		System.out.println("102");
}

	@Override
	public void brake() {
		// TODO Auto-generated method stub
		System.out.println("111");
	}

	@Override
	public void accelerate() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void nitro() {
		// TODO Auto-generated method stub
		
	}
		

}
