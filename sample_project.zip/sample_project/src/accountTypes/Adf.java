package accountTypes;

interface Adf {

}
