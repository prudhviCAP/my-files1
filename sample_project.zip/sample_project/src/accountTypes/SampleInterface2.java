package accountTypes;

public interface SampleInterface2 extends SampleInterface3,SampleInterface4{
	void brake();
	static void name() {
		System.out.println("yes");
	}
	default void age() {
		System.out.println("bye");
	}
	int a=7;
}
