package accountTypes;
public class AccountClass {
	//private int acc;
	
	public int demo=1;
	public 
	void deposit() {
		System.out.println("this is  account deposit");
	}
	public void withdraw() {
		System.out.println("this is account withdraw");
	}
	public void details() {
		int a=123;
		String b="uhhdf";
		System.out.println(a+"  "+b);
		
		
	}
	public AccountClass() {
		super();
		System.out.println("i am super class default");
	}
}
