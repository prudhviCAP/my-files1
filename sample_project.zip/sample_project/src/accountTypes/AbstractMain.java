package accountTypes;

public class AbstractMain {

		public static void main(String[] args) {
			//SampleAbstract obj = new SampleAbstract();
			AbstractSub1 obj1 = new AbstractSub1();
			obj1.age();
			obj1.contact();
			obj1.dob();
			SampleAbstract obj2 = new AbstractSub1();
			obj2.age();
			obj2.contact();
			//obj2.dob();
		}
}
