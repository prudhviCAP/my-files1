package accountTypes;

public class AbstractSub1 extends SampleAbstract {
	public void name() {
		System.out.println("1");
	}
	public void contact() {
		System.out.println("2");
	}
	public void age() {
		System.out.println("3");
	}
	public void dob()
	{
		System.out.println("some method");
	}
}
