package accountTypes;

public class MainInterafce {
		public static void main(String[] args) {
			AbstractSub2 o1=new AbstractSub2();
			o1.age();
			o1.contact();
			//o1.name();
			o1.brake();
		}
}