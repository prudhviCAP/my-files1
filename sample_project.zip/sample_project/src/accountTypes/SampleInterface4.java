package accountTypes;

public interface SampleInterface4 {
	void nitro();
}
