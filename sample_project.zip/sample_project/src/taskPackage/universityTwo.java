package taskPackage;

public interface universityTwo extends universityOne{
	void course();
	void events();
	static void staff()
	{
		System.out.println("i am staff 2.0");
	}
}
