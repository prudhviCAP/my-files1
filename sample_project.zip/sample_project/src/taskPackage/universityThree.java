package taskPackage;

public interface universityThree {

	void branch();
}
