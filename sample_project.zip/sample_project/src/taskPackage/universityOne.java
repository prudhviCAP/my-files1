package taskPackage;

public interface universityOne {
	void students();
	void department();
	static void staff() {
		String staffName;
		//int staffId;
		//String dept;
		System.out.println("i am staff 1");
	}
}
