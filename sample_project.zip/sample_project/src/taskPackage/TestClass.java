package taskPackage;

public class TestClass implements universityTwo,universityThree{

	@Override
	public void students() {
		// TODO Auto-generated method stub
		System.out.println("1");
	}

	@Override
	public void department() {
		// TODO Auto-generated method stub
		System.out.println("2");
	}

	@Override
	public void course() {
		// TODO Auto-generated method stub
		System.out.println("3");
	}

	@Override
	public void events() {
		// TODO Auto-generated method stub
		System.out.println("4");
	}

	@Override
	public void branch() {
		// TODO Auto-generated method stub
		
	}

}
