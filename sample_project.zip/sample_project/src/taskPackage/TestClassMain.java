package taskPackage;

public class TestClassMain {
	public static void main(String[] args) {
		TestClass obj = new TestClass();
		obj.department();
		obj.course();
		obj.events();
		TestClassTwo obj1 = new TestClassTwo();
		obj1.students();
		obj1.course();
		obj1.department();
		universityTwo.staff();
	}
}
