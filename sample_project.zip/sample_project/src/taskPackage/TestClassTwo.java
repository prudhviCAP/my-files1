package taskPackage;

public class TestClassTwo implements universityTwo{

	@Override
	public void students() {
		// TODO Auto-generated method stub
		System.out.println("100");
	}

	@Override
	public void department() {
		// TODO Auto-generated method stub
		System.out.println("101");
	}

	@Override
	public void course() {
		// TODO Auto-generated method stub
		System.out.println("102");
	}

	@Override
	public void events() {
		// TODO Auto-generated method stub
		System.out.println("103");
	}

}
