package exceptionPackage;

public class ExceptionSample {
	public static void main(String[] args) {
		ExceptionSample es = new ExceptionSample();
		es.method();
	}

		void method()
		{
			try
			{
				int arr[]=new int[3];
				int a=10,b=1;
				int c=a/b;
				c++;
				arr[4]= 32;
			}
			catch(ArithmeticException|ArrayIndexOutOfBoundsException ae )
			{
				System.out.println(ae);
				
			}
//			catch(ArrayIndexOutOfBoundsException aoobe) {
//				System.out.println(aoobe);
//			}
		}
}
