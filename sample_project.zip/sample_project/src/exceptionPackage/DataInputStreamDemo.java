package exceptionPackage;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class DataInputStreamDemo {
	
	public static void main(String[] args) throws IOException {
		FileOutputStream fos = new FileOutputStream("newFile.txt");
		
		DataOutputStream dos = new DataOutputStream(fos);
		dos.writeUTF("hi i am doing data outputstream demo");
		dos.writeInt(35);
		//dos.writeDouble(Double.MAX_VALUE);
		//dos.writeInt(Integer.MIN_VALUE);

		FileInputStream fis = new FileInputStream("newFile.txt");
		DataInputStream dis = new DataInputStream(fis);
		System.out.println(dis.readUTF());
//		int i=0;
//		while((i=fis.read())!=-1) {
//			System.out.print((char)i);
//		}
		

}
}