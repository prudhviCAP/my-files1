package exceptionPackage;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class WriteFileDemo {

		public static void main(String[] args) throws IOException {
		//	File y = new File("sample.txt");
		//	String x = "C:\Users\pruthumm\Desktop\New folder";
			FileOutputStream fos = new FileOutputStream("C:\\Users\\pruthumm\\Desktop\\New folder\\sample_project\\hello.txt");
			String x= "some info must be written";
			
			byte[] bt = x.getBytes();
		//	System.out.println(x.);
			fos.write(bt);
		//	System.out.println(fos.flush());
		//	fos.
			fos.close();
			FileInputStream fis = new FileInputStream("C:\\Users\\pruthumm\\Desktop\\New folder\\sample_project\\hello.txt");
			int i=0;
			while((i=fis.read())!=-1) {
		//	char j = (char)i;
				System.out.print(i+" ");
			}
		//	System.out.println(fis.read(bt));
			fis.close();
		}
}
