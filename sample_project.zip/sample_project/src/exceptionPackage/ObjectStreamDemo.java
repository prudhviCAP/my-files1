package exceptionPackage;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class ObjectStreamDemo {

		public static void main(String[] args) throws IOException {
			try(FileOutputStream fos = new FileOutputStream("Product");
			ObjectOutputStream oos = new ObjectOutputStream(fos);){
			
				ProductSample ps = new ProductSample(100,"shoe",2000);
				oos.writeObject(ps);
				oos.close();
			}catch(Exception e) {
				System.out.println(e);
			}
			
			try(FileInputStream fis = new FileInputStream("Product");
					ObjectInputStream ois = new ObjectInputStream(fis);){
					ProductSample ps=(ProductSample) ois.readObject();
					System.out.println(ps);
					ois.close();
					}catch(Exception e) {
						System.out.println(e);
					}
		}
}
