package exceptionPackage;

import java.io.FileReader;
import java.io.FileWriter;

public class CopyFileWrite {
	
	public static void main(String[] args) {
		try(FileReader inputStream = new FileReader("hello.txt");
				FileWriter outputStream = new FileWriter("bye.txt");)
		{
			int c;
			while((c=inputStream.read())!=-1)
			{
				outputStream.write(c);
			}
		}catch(Exception e) {
			System.out.println(e.getMessage());
		}
				
	}

}
