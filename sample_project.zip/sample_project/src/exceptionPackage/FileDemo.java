package exceptionPackage;

import java.io.File;
import java.io.IOException;

public class FileDemo {

	public static void main(String[] args) throws IOException {
		String x = args[0];
		File f = new File(x);
		f.createNewFile();
		System.out.println(f.getName());
		System.out.println(f.getParent());
		System.out.println(f.getAbsolutePath());
		System.out.println(f.length());
		System.out.println(f.canRead());
		System.out.println(f.getCanonicalPath());
	//	System.out.println(f.toURI());
	//	System.out.println(f.createNewFile());
		System.out.println(f.getFreeSpace());
		System.out.println(f.getUsableSpace());
		
	}
}
