
//	enum EnumDemo { A }
public class DQTest {

	String name;
	 int id;
	 public DQTest() {
		 
	 }
	 public DQTest(String name,int id)
	 {
	 this.name = name;
	 this.id=id;
}
}