package lambdaExpressions;

@FunctionalInterface
public interface Calculator {

	abstract public int addition(int num1,int num2);
}
