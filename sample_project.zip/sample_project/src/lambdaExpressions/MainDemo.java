package lambdaExpressions;

import java.util.function.BiFunction;
import java.util.function.Consumer;
import java.util.function.Predicate;
import java.util.function.Supplier;

import org.apache.log4j.chainsaw.Main;

public class MainDemo {
	
	
		
		public static void main(String[] args) {
			
		Consumer<String> consumer = (String str)-> System.out.println(str);
		consumer.accept("Hello LE!");
		
		Supplier<String> supplier = ()->"Hello from Supplier";
		consumer.accept(supplier.get());
		
		Predicate<Integer> predicate = num -> num%2 ==0;
		System.out.println(predicate.test(24));
		System.out.println(predicate.test(15));
		
		BiFunction<Integer,Integer,Integer> biFunction = (x,y) -> x>y?x:y;
		System.out.println(biFunction.apply(14,25));
	 
		}
}
