package lambdaExpressions;

public class LambdaMain{
	
	public static void main(String[] args) {
		Calculator add = (num1,num2) -> num1+num2;
		int result = add.addition(10, 40);
		System.out.println(result);
	}
	
}
