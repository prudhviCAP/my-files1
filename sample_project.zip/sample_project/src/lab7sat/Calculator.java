package lab7sat;

public class Calculator {
	
	
	public double add(double a, double b)
	{
		double c = a+b;
		System.out.println("addition of  a,b is : "+c);
		return c;
	}
	public double subtract(double a, double b)
	{
		double c;
		if(a>b)
		{
			c = a-b;
		}
		else
		{
			c = b-a;
		}
	//	System.out.println("difference of a,b is : "+c);
		return c;
	}
	public double multiply(double a, double b)
	{
		double c= a*b;
	//	System.out.println("multiplication of c is : "+c);
		return c;
	}
	public double divide(double a, double b)
	{
		double c= a/b;
		return c;
	}

}
