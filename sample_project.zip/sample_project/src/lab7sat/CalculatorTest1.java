package lab7sat;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class CalculatorTest1 {
	
	Calculator cal = new Calculator();
	
	@Test
	public void testAdd() {
		assertEquals(70, cal.add(45, 25));
	}
	
	@BeforeAll
	public static void tesBC() {
		System.out.println("Before all test");
	}

	@BeforeEach
	public void testB() {
		System.out.println("Before every test");
	}	

	@Test
	public void testSubtract() {
		assertEquals(70, cal.subtract(95, 25));
	}

	@Test
	public void testMultiply() {
		assertEquals(25, cal.multiply(5, 5));
	}

	@Ignore
	@Test
	void testDivide() {
		assertEquals(2, cal.divide(4, 2));
	}

	@AfterEach
	public void testA() {
		System.out.println("After every test");
	}

	@AfterAll
	public static void testAC() {
		System.out.println("After all test");
	}

}
