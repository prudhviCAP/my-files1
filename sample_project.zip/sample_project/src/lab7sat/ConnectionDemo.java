package lab7sat;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class ConnectionDemo {
	
	public static void main(String[] args) throws ClassNotFoundException {
		
	
	try {
		Class.forName("oracle.jdbc.driver.OracleDriver");
		
		Connection con = DriverManager.getConnection("jdbc:oracle:thin:@10.219.34.3:1521/orcl","trg707","training707");
		
		Statement st = con.createStatement();
		PreparedStatement pst = con.prepareStatement("");
		
		ResultSet rs = st.executeQuery("select * from prithvi where id=102");
		while(rs.next())
		{
			System.out.println(rs.getInt(1));
			System.out.println(rs.getString(2));
		}
		//con.close();
	}
	catch(SQLException sqle)
	{
		System.out.println(sqle);
	}
}
}