import java.util.Scanner;

public class ScannerUse {
	public static void main(String[] args) {
		int upperCharCount=0,lowerCharCount=0;
		Scanner in = new Scanner(System.in);
		String inp;
		System.out.println("enter string: ");
		inp = in.nextLine();
		if(!inp.isEmpty())
		{
			for(char ch:inp.toCharArray())
			{
				if(!Character.isDigit(ch) && Character.isAlphabetic(ch))
				{
					if(Character.isUpperCase(ch))
					{
						upperCharCount++;
					}
					else if(Character.isLowerCase(ch))
					{
						lowerCharCount++;
					}
				}
			}
			
		}
		System.out.println("Upper char count is "+upperCharCount);
		System.out.println("lower char count is" +lowerCharCount);
		/*Scanner scan= new Scanner(System.in);
		while(true) {
			System.out.println("What your name?");
			String input = scan.nextLine();
			if(input.length()==0)
			{
				break;
			}
			System.out.println("your name is "+input);
		}
		scan.close();*/
	}
}
