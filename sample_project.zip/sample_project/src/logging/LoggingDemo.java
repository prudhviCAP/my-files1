package logging;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

public class LoggingDemo {
	
	static Logger myLogger = Logger.getLogger(LoggingDemo.class.getName());
	Object x;
	
	public void do_something(int a ,float b)
	{
		myLogger.info("do_something are :"+a+" "+b);
		myLogger.debug("operation performed successfully");
		if(x==null)
		{
			myLogger.error("value of x is null");
			
		}
	}
	public static void main(String[] args) {
		PropertyConfigurator.configure("resource/log4j.properties");
		LoggingDemo m = new LoggingDemo();
		m.do_something(1,(float)1.2);
	}

}
