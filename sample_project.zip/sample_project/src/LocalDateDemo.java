import java.time.LocalDate;
import java.time.Month;
import java.time.Period;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.FormatStyle;
import java.util.Scanner;

public class LocalDateDemo {

	public static void main(String[] args) {
		LocalDate localDate=LocalDate.now();
		System.out.println(localDate);
		LocalDate independenceDay= LocalDate.of(1947,Month.AUGUST,15);
		System.out.println(independenceDay);
		//boolean localDate1=LocalDate.isLeapYear(2014);
		System.out.println(localDate.plusMonths(12));
		System.out.println(localDate.isLeapYear());
		System.out.println(localDate.getDayOfYear());
		System.out.println(localDate.hashCode());
		System.out.println(localDate.lengthOfYear());
		System.out.println(localDate.atStartOfDay());
		System.out.println(localDate.isBefore(independenceDay));
		System.out.println(localDate.lengthOfMonth());
		System.out.println(localDate.getEra());
		System.out.println(localDate.plusWeeks(53));
		
		ZonedDateTime zonedTime=ZonedDateTime.now();
		System.out.println("India: "+zonedTime);
		
		ZonedDateTime zonedTime1=ZonedDateTime.now(ZoneId.of("Europe/Paris"));
		System.out.println(zonedTime1);
		
		DateTimeFormatter formatter = DateTimeFormatter.ofLocalizedDate(FormatStyle.SHORT);
		System.out.println(formatter);
		
		DateTimeFormatter formatter1 = DateTimeFormatter.ofLocalizedDate(FormatStyle.FULL);
		System.out.println(formatter1);
		
		DateTimeFormatter formatter2 = DateTimeFormatter.ofLocalizedDate(FormatStyle.MEDIUM);
		System.out.println(formatter2);
		
		DateTimeFormatter formatter3 = DateTimeFormatter.ofLocalizedDate(FormatStyle.LONG);
		System.out.println(formatter3);
		
		System.out.println(localDate.format(formatter1));
		System.out.println(localDate.format(formatter));
		System.out.println(localDate.format(formatter2));
		System.out.println(localDate.format(formatter3));
		
		LocalDate dateOfBirth = LocalDate.of(1996,Month.SEPTEMBER,16);
		Period period = dateOfBirth.until(localDate);
		System.out.println(period);
		System.out.println(period.getYears());
		System.out.println(period.getMonths());
		System.out.println(period.getDays());
		
		
	//	Period period1 = localDate.until(dateOfBirth);
		//System.out.println(period1);
		
		DateTimeFormatter formatterDate = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		Scanner sc = new Scanner(System.in);
		System.out.println("enter date in dd/MM/yyyy format: ");
		String input = sc.nextLine();
		
		LocalDate enteredDate= LocalDate.parse(input,formatterDate);
		System.out.println("Entered Date: "+enteredDate);
		sc.close();
		
		
		
		
	}
}
