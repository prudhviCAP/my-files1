
public class DQTest1 extends DQTest{
	public DQTest1() {
		
	}

	public static void main(String []args)
	 {
	 DQTest1 mgr = new DQTest1();
	 }
}
  