package lab9;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Enumeration;
import java.util.Properties;

public class PropertiesDemo {
	
	private static void saveProperties(Properties p,String fileName)
	{
		try
		{
			OutputStream propsFile = new FileOutputStream(fileName);
			p.store(propsFile, "properties file application");
			propsFile.close();
		}catch (IOException ioe)
		{
			System.out.println(ioe);
		}
	}
	
	private static Properties loadProperties(String fileName )
	{
		Properties tempProp = new Properties();
		try
		{
			InputStream propsFile = new FileInputStream(fileName);
			tempProp.load(propsFile);
			propsFile.close();
		}catch(IOException ioe)
		{
			System.out.println(ioe);
		}
		return tempProp;
	}
	
	private static Properties createDefaultProperties()
	{
		Properties tempProp = new Properties();
		tempProp.setProperty("URL", "jdbc:oracle:thin:@10.219.34.3:1521:orcl");
		tempProp.setProperty("driver", "oracle.jdbc.driver.OracleDriver");
		tempProp.setProperty("username", "trg707");
		tempProp.setProperty("password", "training707");
		return tempProp;
	}

	private static void printProperties(Properties p,String s)
	{
		p.list(System.out);
	}
	
	public static void main(String[] args) {
		
		final String PROPFILE = "MyApplication.properties";
		Properties myProp;
		Properties myNewProp;
		
		myProp = createDefaultProperties();
		printProperties(myProp,"Newly created (Default) properties");
		
		saveProperties(myProp,PROPFILE);
		
		myNewProp = loadProperties(PROPFILE);
		
		printProperties(myNewProp,"Loaded Properties");
		
		//myNewProp = alterProperties(myProp);
		
		printProperties(myNewProp,"After Altering properties");
		
		saveProperties(myNewProp,PROPFILE);
		
		Properties myNewProp1 = loadProperties(PROPFILE);
		
		Enumeration enProps = myNewProp1.propertyNames();
		
		String key = "";
		String param[];
		param = new String[4];
		int i= 0;
		while(enProps.hasMoreElements())
		{
			key = (String)enProps.nextElement();
			System.out.println(key);
			param[i] = (String)myNewProp1.getProperty(key);
			System.out.println(" "+key+" ->"+myNewProp1.getProperty(key));
			i++;
		}
	}
}

