package sample_project;

public class SwitchExample {
		public static void main(String[] args) {
			String currentDay = args[0];
			switch(currentDay) {
			case "MONDAY":
			case "TUESDAY":
			case "WEDNESDAY":
			case "THURSDAY":
			case "FRIDAY":
			System.out.println("boring");
			break;
			case "SATURDAY":
				System.out.println("wait for sunday");
			break;
			case "SUNDAY":
				System.out.println("its here");
			break;
			default:
				System.out.println("everyday except sunday is not good");
			break;
			}
		}
}
