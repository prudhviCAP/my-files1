package sample_project;

public class BasicIfElse {
	public static void main(String[] args) {
		int age=45;
		if(age>15 && age<30)
				System.out.println("i have become old");
		else if(age>30)
				System.out.println("I may die soon");
		else
			System.out.println("i was just born");
	}
}
