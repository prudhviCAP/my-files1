package sample_project;

import static java.lang.Math.*;
public class Box {
	double bxWidth;
	double bxHeight;
	double bxDepth;
	int count;
	
	public Box() {
		//this(220);
		count++;
		System.out.println("im default  "+count);
		// TODO Auto-generated constructor stub
	}
	
	

	public Box(double bxWidth) {
		///this(10,20,30);
		count++;
		//this.bxWidth = bxWidth;
		System.out.println("this is one param constructor  "+ count);
	}



	public Box(double bxWidth, double bxHeight, double bxDepth) {
		this.bxWidth = bxWidth;
		this.bxHeight = bxHeight;
		this.bxDepth = bxDepth;
		count++;
		System.out.println("this is three param constructor  "+ count);
	}



	static double calcVolume() {
		//return bxWidth*bxDepth*bxHeight;
		System.out.println(sqrt(8));
		return 2;
	}
}
