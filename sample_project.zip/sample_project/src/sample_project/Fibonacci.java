package sample_project;

public class Fibonacci {
	
	public void fibonacci(int noOfTerms)
	{
		int num1=0,num2=1,num3 = 1;
		for(int i=0;i<noOfTerms;i++)
		{
			num1 = num2;
			num2 = num3;
			num3 = num1 + num2;
			System.out.println(num1);
		}
			
	}
	public static void main(String[] args) {
		Fibonacci fib = new Fibonacci();
		int noOfTerms = Integer.parseInt(args[0]);
		fib.fibonacci(noOfTerms);
	}

}
