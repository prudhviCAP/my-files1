package sample_project;

public class Car extends Addition{
		   @Override
		   public int getTyres() {
		      return super.getTyres()+1;
		   } 
}

