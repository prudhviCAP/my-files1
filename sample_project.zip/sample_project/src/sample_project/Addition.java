package sample_project;

/*public class Addition {
		int a=21,b=16;
		void add()
		{
			int c;
			c=a+b;
			System.out.println("result is : "+c);
		}
	public static void main(String[] args) {
		Addition obj=new Addition();
		obj.add();
		String str = new String();
		Object str1 = new Object();
	}

}
	class StringCheck {
		
		    static String str[]=new String[50];
		    public static void main(String[] args) {
		        for(int i=0; i<str.length; i++) {
		           str[i] = null;
		           System.out.print(str[i]);
		        }
		    }
		  } 

*/
public abstract class Addition {
	  private int tyres;
	  public void setTyres(int tyres) {
	    this.tyres = tyres;
	  } 
	  public int getTyres() {
	    return tyres;
	  } 
	 }

