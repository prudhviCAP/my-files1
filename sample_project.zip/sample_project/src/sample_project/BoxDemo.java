package sample_project;

public class BoxDemo {
	public static void main(String[] args) {
		//Box box;
		//box = new Box();
		
		//System.out.println(Box.calcVolume());
		
		
		//Box box1 = new Box(10,20,30);
		//System.out.println(box1.calcVolume());
		
		//Box box2 = new Box(30);
		
		//System.out.println(box2.bxWidth);
		
		/*Product prod = new Product();
		prod.setProductId(111);
		prod.setProductName("sugar");
		prod.setProductPrice(125);
		System.out.println(prod);
		System.out.println(prod.getProductName());*/
		
		System.out.println(Months.Jun.getDays());
		
	}
}
