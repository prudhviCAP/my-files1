package sample_project;

public class Palindrome
{
	public void palindrome(int input)
	{
		int rem=0,pal=0;
		while(input>0)
		{
			rem = input%10;
			input = input/10;
			pal = (pal*10) + rem;
		}
		System.out.println("palindrome is: "+pal);
	}
	public static void main(String[] args)
	{
		
		int input = Integer.parseInt(args[0]);
		System.out.println("given number is: "+input);
		Palindrome obje = new Palindrome();
		obje.palindrome(input);
	}
}
