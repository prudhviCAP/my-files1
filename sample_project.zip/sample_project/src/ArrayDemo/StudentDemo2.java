package ArrayDemo;

import java.util.Collections;

public class StudentDemo2
{

		 int age;
		 String name;
		 int rollNo;
		
		public StudentDemo2(int age, String name, int rollNo) {
			super();
			this.age = age;
			this.name = name;
			this.rollNo = rollNo;
		}

		

	}
		
	
