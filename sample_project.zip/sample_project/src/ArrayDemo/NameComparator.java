package ArrayDemo;

import java.util.Comparator;

public class NameComparator implements Comparator{

		
	@Override
	public int compare(Object o1, Object o2) {
		// TODO Auto-generated method stub
		StudentDemo2 stu1=(StudentDemo2) o1;
		StudentDemo2 stu2=(StudentDemo2) o2;
		return stu1.name.compareTo(stu2.name);
	}

		
}
