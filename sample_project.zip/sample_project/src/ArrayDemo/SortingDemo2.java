package ArrayDemo;

import java.util.ArrayList;
//import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
//import java.util.List;

public class SortingDemo2 {

		public static void main(String[] args) {
			
				ArrayList<StudentDemo2> al = new ArrayList<StudentDemo2>();
				
				al.add(new StudentDemo2(12,"Aditya",1));
				al.add(new StudentDemo2(10,"subham",2));
				al.add(new StudentDemo2(17,"Sohan",3));
				al.add(new StudentDemo2(22,"Prudhvi",16));
				al.add(new StudentDemo2(20,"Ram Charan",50));
				al.add(new StudentDemo2(13,"Madhav",17));
//				
//				for(StudentDemo2 y:al)
//				{
//					System.out.println(y.age);
//				}
				
			//	al.compareTo(y);
				Collections.sort(al,new NameComparator());
					System.out.println("after sorting ");
			//		System.out.println();
					
//				for(StudentDemo m:al)
//				{
//				System.out.println(m.age);
//				}
//					System.out.println(y.age);
				Iterator<StudentDemo2> itr = al.iterator();
			
				while(itr.hasNext()) {
					StudentDemo2 stu=itr.next();
					System.out.println(stu.name);
	}
		}
}
