package ArrayDemo;

public class ArraySample {

		int empId;
		String empName;
		double salary;
		
		
		public ArraySample(int empId, String empName, double salary) {
			super();
			this.empId = empId;
			this.empName = empName;
			this.salary = salary;
		}
		
		
}
