package ArrayDemo;

public class ArraySampleMain
{

		public static void main(String[] args)
	{
		ArraySample arr[] = new ArraySample[3];
		arr[0] = new ArraySample(166172,"charan",20000);
		arr[1] = new ArraySample(166173,"dinesh",20000);
		arr[2] = new ArraySample(166174,"prudhvi",20000);
		
		for(int i=0;i<arr.length;i++)
		{
			System.out.println(arr[i].empName);
		}
		
	}
}
