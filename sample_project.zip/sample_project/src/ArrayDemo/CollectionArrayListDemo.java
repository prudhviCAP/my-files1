package ArrayDemo;

import java.util.ArrayList;
import java.util.*;

public class CollectionArrayListDemo {

		public static void main(String[] args) {
			
			ArrayList arrList = new ArrayList();
			
			arrList.add("hi");
			arrList.add(33);
			arrList.add("hello");
			arrList.add("no");
			arrList.add('c');
			arrList.remove(2);
			System.out.println(arrList);
			
			arrList.clear();
			System.out.println(arrList);
			
			
			SortedSet ts = new TreeSet();
			ts.add("hi");
			ts.add("hello");
			ts.add("alma");
			ts.add("ball");
			ts.add("ball");
			System.out.println(ts);
			ts.remove("ball");
			System.out.println(ts);
			
			Map mp = new HashMap();
			mp.put("hello","hi");
			System.out.println(mp);
			//mp.add("hello");
			//mp.add("alma");
			//mp.add("ball");
			//mp.add("ball");
			
			
			
			
		}
}
