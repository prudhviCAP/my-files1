package ArrayDemo;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

public class SortingDemo {

		public static void main(String[] args) {
			
				ArrayList<StudentDemo> al = new ArrayList<StudentDemo>();
				
				al.add(new StudentDemo(12,"Aditya",1));
				al.add(new StudentDemo(10,"subham",2));
				al.add(new StudentDemo(17,"Sohan",3));
				al.add(new StudentDemo(22,"Prudhvi",16));
				al.add(new StudentDemo(20,"Ram Charan",50));
				al.add(new StudentDemo(13,"Madhav",17));
				
				for(StudentDemo y:al)
				{
					System.out.println(y.age);
				}
				
			//	al.compareTo(y);
				Collections.sort(al);
					System.out.println("after sorting ");
					
					for(StudentDemo m:al)
					{
						System.out.println(m.age);
					}
				//	System.out.println(y.age);
		//		Iterator itr = al.iterator();
			
				
		}
}
