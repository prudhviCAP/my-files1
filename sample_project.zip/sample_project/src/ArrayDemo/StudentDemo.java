package ArrayDemo;

import java.util.Collections;

public class StudentDemo implements Comparable<StudentDemo>{

		 int age;
		 String name;
		 int rollNo;
		
		public StudentDemo(int age, String name, int rollNo) {
			super();
			this.age = age;
			this.name = name;
			this.rollNo = rollNo;
		}

		@Override
		public int compareTo(StudentDemo o) {
			// TODO Auto-generated method stub
			if(age==o.age)
				return 0;
			else if(age>o.age) 
				return 1;
			else
				return -1;
			
		}
		
		
}
