package ArrayDemo;

import java.util.Arrays;

public class ArgumentSample {

		public static void main(String[] args) {
			
				int array[] ={231,11,29,380,77};
				Arrays.sort(array,0,3);
				for(int i=0;i<array.length;i++)
					System.out.println(array[i]);
				//for(int x : array)
				//{
				//	System.out.println(x);
				//}
				//System.out.println(Arrays.binarySearch(array,11));
				
//				int array1[]=Arrays.copyOf(array,3);
////				for(int i=0;i<array1.length;i++)
////				{
////					System.out.println(array1[i]);
////				}
//				
//				for(int y:array1)
//				{
//					System.out.println(y);
//				}
//				
//				int array2[] = Arrays.copyOfRange(array,2,6);
//				for(int l:array2)
//					System.out.println(l);
				
		}
}
