package util;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

public class DBConnection {

		public static void main(String[] args) throws ClassNotFoundException, SQLException, IOException 
		{
			
			Connection con = getConnection();
		}
		static Connection getConnection() throws SQLException, ClassNotFoundException, IOException
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			FileInputStream fis = new FileInputStream("resources/DB.properties");
			Properties prop = new Properties();
			prop.load(fis);
			
			String u= prop.getProperty("URL");
			String user = prop.getProperty("username");
			String pass=prop.getProperty("password");
			Connection c = DriverManager.getConnection(u,user,pass);
			return c;
		}
}
