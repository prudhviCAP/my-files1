
public class AgeException extends Exception
{

	public AgeException(String str)
	{
		
		super();
		
		System.out.println(str);
		
	}
	
}
