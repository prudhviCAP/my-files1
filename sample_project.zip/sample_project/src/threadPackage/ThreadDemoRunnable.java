package threadPackage;

public class ThreadDemoRunnable implements Runnable{

	@Override
	public void run() {
		// TODO Auto-generated method stub
		System.out.println(Thread.currentThread().getName()+" thread start ");
		for(int row=2;row<5;row++)
		{
			for(int num=0;num<10;num++)
			{
				System.out.print(row*num+" ");
			}
			System.out.println("");
		}
		System.out.println(Thread.currentThread().getName()+" thread ends ");
		
	}

}
