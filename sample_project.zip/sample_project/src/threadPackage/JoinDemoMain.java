package threadPackage;

public class JoinDemoMain {
	
	//public static void main(String[] args) {
		
	//	ThreadDemoRunnable th = new ThreadDemoRunnable();
//		Thread t1 = new Thread(new ThreadDemoRunnable());
//		t1.start();
//	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Thread t1 = new Thread(new ThreadDemoRunnable(),"one");
		Thread t2 = new Thread(new ThreadDemoRunnable(),"two");
		Thread t3 = new Thread(new ThreadDemoRunnable(),"three");
		
		t1.start();
		try
		{
			t1.join(1000);
			
		}
		catch(InterruptedException e)
		{
			System.err.println(e.getMessage());
		}
		
		t2.start();
		try
		{
			t1.join(1000);
		}
		catch(InterruptedException e1)
		{
			System.err.println(e1.getMessage());
		}
		
		t3.start();
		try
		{
			t1.join();
			t2.join();
			t3.join();
		}
		catch(InterruptedException e1)
		{
			System.err.println(e1.getMessage());
		}
		System.out.println(t1.isAlive());
		
		System.out.println("All threads dead");
		System.out.println(t1.MIN_PRIORITY+2);
		System.out.println(t1.MAX_PRIORITY);
		System.out.println(t1.NORM_PRIORITY);
	}

}
