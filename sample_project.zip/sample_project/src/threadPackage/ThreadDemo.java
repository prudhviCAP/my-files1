package threadPackage;

public class ThreadDemo extends Thread{

	Thread t = new Thread();
	public void run()
	{
		for(int i=0;i<10;i++)
		{
			try {
				t.sleep(3000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			System.out.println(i+"  ");
		}
	}
	public static void main(String[] args) {
		ThreadDemo td = new ThreadDemo();
		td.run();
	}
}
