import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RegexSample {
	public static void main(String[] args) {
		//String input = "Shop,Mop,Hopping,Chopping,bishop";
		//Pattern pattern = Pattern.compile("hop");
		//Matcher matcher = pattern.matcher(input);
		//System.out.println(matcher.matches());
		//while(matcher.find()) {
		//	System.out.println(matcher.group()+" : "+matcher.start()+" : "+matcher.end());
			
		RegexSample re = new RegexSample();
		re.mobi("prudhvi.a.t78$hu@capgemini.com");
	//	}
	}	
//		public void meth(String param)
//		{
//			Pattern x = Pattern.compile("[A-Z][a-z]{2,6}");
//			Matcher matcher1 = x.matcher(param);
//			System.out.println(matcher1.matches());
//		}
		public void mobi(String num)
		{
			Pattern x = Pattern.compile("[a-z.$[0-9]]*@capgemini.com");
			Matcher matcher1 = x.matcher(num);
			System.out.println(matcher1.matches());
		}
		
}
